function [ mes ] = cumulate( mes )
%CUMULATE Summary of this function goes here
%   Detailed explanation goes here
[A,B]=size(mes);
for a=1:A
    for b=2:B
        if mes(a,b)<mes(a,b-1)-pi
            mes(a,b:B)=mes(a,b:B)+2*pi;
        end
    end
end

end

