function [ U_MM ,time_ukf ] = UKF_schol( n_mac,M0,P0,Q,para,Y,R )
%% estimtate with UKF - (UKF-schol)
tstart3 = tic;
s_pos = para{9};
n_s = size(s_pos,1);
U_MM = zeros(n_s,size(Y,2));
U_MM(:,1) = M0(s_pos);
U_PP = zeros(n_s,n_s,size(Y,2));
M = M0(s_pos);
para{11} = M0(setdiff(1:4*n_mac,s_pos));
P = P0;
f_func = @power_system_f_tra1;
% h_func = @power_system_h_tra;
h_func = @observe_model_func;
for k=2:size(Y,2)
   [M,P] = ukf_predict1(M,P,f_func,Q,para);
   [M,P] = ukf_update1(M,P,Y(:,k),h_func,R,para);
   U_MM(:,k) = M;
   U_PP(:,:,k) = P;
end
time_ukf = toc(tstart3);

end

