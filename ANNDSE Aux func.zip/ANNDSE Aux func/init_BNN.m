function [net] = init_NN(net_par,f,method);   

    i = net_par(1);
    h = net_par(2);
    o = net_par(3);
    gamma = net_par(4);
    
    if(method == 1)    
        % Gaussian Distribution between -0.05 to 0.05 
        IW = (rand(h,i+1)-0.5)/f;
        OW = (rand(o,h+1)-0.5)/f;
        
    elseif (method == 2)
        IW = sqrt(gamma/i).*(randn(h,i+1)-0.5)/f;
        OW = sqrt(gamma/i).*(randn(o,h+1)-0.5)/f;
    end
    
    net = struct('IW',IW,'OW',OW,'net_par',...
                 net_par,'h_sum',[],'h_op',[],...
                 'input',[],'output',[]);
             
end