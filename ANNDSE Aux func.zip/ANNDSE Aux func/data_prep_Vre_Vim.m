function [time,dt,Vre,Vim,Vang_mes,mac_ang,mac_spd,RV_p,Param,U_MM_sq,U_MM,time_srukf,time_ukf]= data_prep_Vre_Vim(filename)
U_MM=[];
time_ukf=[];

data_generation;

time = xlsread(filename,'time','','basic');
dt = time(1);
time = time(2);

Vre = Y(1:n_mac,:);
Vim = Y(n_mac+1:2*n_mac,:);
bus_v = Vre+1i*Vim;
Vang_mes=cumulate(angle(bus_v));

mac_ang = states_nonoise(1:n_mac,:);
mac_spd = states_nonoise(n_mac+1:2*n_mac,:)/para{2};

mac_con = xlsread(filename,'mac_con','','basic');
Et  = xlsread(filename,'eterm',['A1:A' num2str(n_mac)],'basic');
xdd = mac_con(:,7);
H   = mac_con(:,16);
D   = mac_con(:,17); 
Pm = xlsread(filename,'pmech',['A1:A' num2str(n_mac)],'basic'); 

Param = [xdd H Et D Pm];

%}

end















