function [out,net] = NN_forward(inp,net)
%----- FORWARD PROPAGATION ------

    net.h_sum  = net.IW*[inp; 1];
    net.h_op   = sigmoid(net.h_sum);
    out        = net.OW*[net.h_op; 1];
    net.output = out; 
    net.input  = inp;

function [sigm_out] = sigmoid(sigm_in)
sigm_out = (1./(1+exp(-sigm_in)));