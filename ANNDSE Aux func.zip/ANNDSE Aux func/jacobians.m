function [A,Hk] = jacobians(delta,delta_pre,V_mes,Param,RV_p)

    Vreal = real(V_mes);
    Vimag = imag(V_mes);

    xdd = Param(:,1);    
    H   = Param(:,2);    
    Et  = Param(:,3);    
    D   = Param(:,4);    
    wB  = 2*pi*60;

    m = size(Vreal,1); n = size(Vreal,1);
    % ----------- Jacobian Calculations -----------
    for i = 1:m
        for j = 1:n
            dR_dD(i,j) = -abs(RV_p(i,j)).*Et(j).*sin(angle(RV_p(i,j))+ delta(j));
            dI_dD(i,j) =  abs(RV_p(i,j)).*Et(j).*cos(angle(RV_p(i,j))+ delta(j));
            Hk((2*i)-1,(j*2)-1) = -abs(RV_p(i,j)).*Et(j).*sin(angle(RV_p(i,j))+ delta_pre(j));
            Hk((2*i),(j*2)-1)   =  abs(RV_p(i,j)).*Et(j).*cos(angle(RV_p(i,j))+ delta_pre(j));
        end
    end
    Hk(:,2*m) = 0;
    % ----------- System Matrix Jacobian -----------
    for i = 1:n, for j = 1:n
            A((2*i)-1,(2*i)-1)  =  0;
            A((2*i)-1,(2*i))    =  wB;
            A((2*i),(2*i)-1)    =  -((Et(i)).*((cos(delta(i)).*Vreal(i))+(sin(delta(i)).*dR_dD(i,i))...
                                    +(sin(delta(i)).*Vimag(i))-(cos(delta(i)).*dI_dD(i,i))))...
                                    ./(2*H(i)*xdd(i));
            A((2*i),(2*i))      =  -D(i)./(2*H(i));
            if i ~= j
                A((2*i)-1,(2*j)-1) = 0;
                A((2*i)-1,(2*j))   = 0;
                A((2*i),(2*j)-1)   = -((Et(i)).*((sin(delta(i)).*dR_dD(i,j))...
                                     -(cos(delta(i)).*dI_dD(i,j))))./(2*H(i)*xdd(i));
                A((2*i),(2*j))     = 0;
            end
        end
    end

end