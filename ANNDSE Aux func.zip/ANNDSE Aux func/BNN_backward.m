function [net] = NN_backward(net,error,gamma);

lambda = 0.0000;
alpha1 = 1;
alpha2 = 1;

IW = net.IW;
OW = net.OW;
input = net.input;
h_op  = net.h_op;
h_sum = net.h_sum;

b = 1;
    %---------------- BACK PROPAGATION ------------------------------
    da_by_dz = [];
    da_by_db = [];
    delta    = [];

    da_by_dz   = 1;     % linear output
    delta      = da_by_dz.*error;

    temp = OW'*delta;
    temp(length(temp)) =[];

    % Gradient Discent Algorithm to update Layer Weights
    net.OW  =   (alpha1*OW -(gamma*(delta*[h_op' b] + lambda*OW)));

    da_by_dz   = h_op.*(1 - h_op);    % sigmoid output
    delta     =  temp.*da_by_dz;

    net.IW  =   (alpha2*IW -(gamma*(delta*[input' b] + lambda*IW)));

end    