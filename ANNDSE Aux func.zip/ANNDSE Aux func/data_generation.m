
load(filename);

n_mac = size(para{1},1);
n_s = 2*n_mac;
noisedltbd = 0.5*pi/180;
noisewbd = 1e-3*2*pi*60;
noiseeqpbd = 1e-3;
noiseedpbd = 1e-3;
P = [noisewbd^2*eye(n_mac) zeros(n_mac); ...
     zeros(n_mac) noisedltbd^2*eye(n_mac)]; 

%% Refresh data and parameters
G = xlsread(filename,'real_Y_GG','','basic');
B = xlsread(filename,'imag_Y_GG','','basic');
Y_GG = G + 1i*B;
para{6} = Y_GG;
real_rec_V1 = xlsread(filename,'real_rec_V1','','basic');
imag_rec_V1 = xlsread(filename,'imag_rec_V1','','basic');
rec_V1 = real_rec_V1 + 1i*imag_rec_V1;
RV_p = rec_V1(para{1}(:,2),:);
para{12} = RV_p;

%% simulate
t0 = 0;
Tfinal = 10;
sensorfreq = 120;
tsequence = t0:1/sensorfreq:Tfinal;
% slove ODE
para{5} = 1/sensorfreq;
s_pos = para{9};
states_nonoise = zeros(4*n_mac,size(tsequence,2));
states_nonoise(:,1) = x0(:,1);

for i=2:size(tsequence,2)
    states_nonoise(:,i) = power_system_f_tra(states_nonoise(:,i-1),para);
end

% states_nonoise = states_nonoise(s_pos,:);
Q = diag((0.01*max(abs(diff(states_nonoise(s_pos,:)')))).^2);
processNoise = gauss_rnd(zeros(n_s,size(tsequence,2)), Q);
states = states_nonoise(s_pos,:) + processNoise;
states_nonoise = states_nonoise(s_pos,:);
%% measurements
sensorfreq = 1/para{5};
ratio = (size(tsequence,2)-1)/sensorfreq/Tfinal;
tsequence = tsequence(1:ratio:end);
states = states(1:ratio:end,:);

% Vre Vim
para{12} = RV_p;
Y_real = zeros(2*n_mac,size(states,2));
para{13} = zeros(n_mac,1);% initialize last delta
Y_real(:,1) = observe_model_func(states(:,1),para);
for i=2:size(states,2)
    Y_real(:,i) = observe_model_func(states(:,i),para);
end
R = diag(1e-2^2*ones(1,2*n_mac));
Y = Y_real;
for i=2:2*n_mac 
    Y(i,:) = Y(i,:) + R(i,i).*randn(1,size(Y,2));
end

% SR-UKF and UKF-schol
[U_MM_sq ,time_srukf] = SRUKFonly(n_mac,x00,P,Q,para,Y,R);
if n_mac==3
    [ U_MM ,time_ukf ] = UKF_schol(n_mac,x00,P,Q,para,Y_real,R);
end