    function [array] = alternate(array1,array2)
        array = reshape([array1'; array2'],1,[])';
    end