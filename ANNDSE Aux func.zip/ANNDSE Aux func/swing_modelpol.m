function [delta,omega,omega_dt] = swing_modelpol(delta,omega,Vang,Parameters,dt)

theta = Vang;
    
% Machine parameters 
    xdd = Parameters(:,1);    % transient reactances of 16 machines
    H   = Parameters(:,2);    % Inertia constants of 16 machines
    Et  = Parameters(:,3); 	  % Magnitude of Terminal Voltages
    D   = Parameters(:,4);    % Damping Co-efficient
    Pm  = Parameters(:,5);    % Mechanical Power    
    wB  = 2*pi*60;            % base angular speed
    Pe          = (Et./xdd).*sin(delta-theta);
    omega_dt    = (1./(2*H)).*(Pm - Pe - (D.*(omega - 1)));
    delta      = (wB*(omega - 1)*dt)  + delta;
    omega      = (omega_dt*dt)        + omega;
end



