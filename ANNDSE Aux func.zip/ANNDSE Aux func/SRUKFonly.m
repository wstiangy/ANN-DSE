% sr-ukf DSE filter for 9 bus and 140 bus system
function [U_MM_sq ,time_srukf] = SRUKFonly(n_mac,M0,P0,Q,para,Y,R)
%% estimate with SR-UKF
tstart2 = tic;
s_pos = para{9};
n_s = size(s_pos,1);
U_MM_sq = zeros(n_s,size(Y,2));
U_MM_sq(:,1) = M0(s_pos);
U_PP_sq = zeros(n_s,n_s,size(Y,2));
M_sq = M0(s_pos);
para{11} = M0(setdiff(1:4*n_mac,s_pos));
P_sq = chol(P0);
f_func = @power_system_f_tra1;
% h_func = @power_system_h_tra;
h_func = @observe_model_func;
for k=2:size(Y,2)
   [M_sq,P_sq] = ukf_predict1_sr(M_sq,P_sq,f_func,Q,para);
   [M_sq,P_sq] = ukf_update1_sr(M_sq,P_sq,Y(:,k),h_func,R,para);
   U_MM_sq(:,k) = M_sq;
   U_PP_sq(:,:,k) = P_sq;
end
time_srukf = toc(tstart2);

end