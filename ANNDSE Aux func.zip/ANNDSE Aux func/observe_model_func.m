function M_est = observe_model_func(x,para)

Et = para{4};
RV_p = para{12};
theta_last = para{13};

delta = x(para{8},:);
E = Et.*(cos(delta)+1i*sin(delta));
V = RV_p*E;
mag = abs(V);
ang = angle(V);
Vre = real(V);
Vim = imag(V);

M_est = [Vre;Vim];
end

